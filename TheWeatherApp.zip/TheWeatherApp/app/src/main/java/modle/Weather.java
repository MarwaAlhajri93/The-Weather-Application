package modle;

/**
 * Created by alialhajri on 2/28/18.
 */

public class Weather {

    public Location location;
    public String iconData;
    public currentCondition currentCondition=new currentCondition();
    public Temprature temprature =new Temprature();
    public wind wind=new wind();
    public clouds Clouds=new clouds();



}
