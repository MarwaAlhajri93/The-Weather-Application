package modle;

/**
 * Created by alialhajri on 2/28/18.
 */

public class clouds {
    private  int precipitation;

    public int getPrecipitation(){
        return precipitation;
    }

    public void setPrecipitation(int precipitation) {
        this.precipitation = precipitation;
    }
}
