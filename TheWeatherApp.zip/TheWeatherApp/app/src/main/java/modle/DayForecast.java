package modle;

/**
 * Created by alialhajri on 2/28/18.
 */
import java.text.SimpleDateFormat;
import java.util.Date;
public class DayForecast extends WeatherForecast{


    public ForecastTemp forecastTemp = new ForecastTemp();
    private static SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    public long timestamp;
    public Weather weather;

    /*
    * Forecast temperature
    * */
    public class ForecastTemp {
        public float day;
        public float min;
        public float max;
        public float night;
        public float eve;
        public float morning;
    }

    public String getStringDate() {
        return sdf.format(new Date(timestamp));
    }
}
