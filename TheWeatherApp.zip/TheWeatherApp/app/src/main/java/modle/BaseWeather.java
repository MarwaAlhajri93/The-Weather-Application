package modle;

/**
 * Created by alialhajri on 2/28/18.
 */

public class BaseWeather {
    private WeatherUnit unit;

    public WeatherUnit getUnit() {
        return unit;
    }

    public void setUnit(WeatherUnit unit) {
        this.unit = unit;
    }

    public static class WeatherUnit {
        public String speedUnit;
        public String tempUnit;
        public String pressureUnit;
        public String distanceUnit;
    }
}
