package com.example.marwaalhajri.theweatherapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONException;

import modle.JSONWeatherParser;
import modle.Weather;
import modle.WeatherForecast;
import modle.WeatherHttpClient;

public class MainActivity extends AppCompatActivity {

    private TextView cityText;
    private TextView temp;
    private ImageView imgView;
    private TextView unitTemp;
    private TextView condDescr;
    private ViewPager pager;
    private Weather weather;

    private static String forecastDaysNum = "3";
    String city = "Muscat, Oman";
    private String lang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cityText = (TextView) findViewById(R.id.cityText);
        temp = (TextView) findViewById(R.id.temp);
        unitTemp = (TextView) findViewById(R.id.unittemp);
        unitTemp.setText("C");
        condDescr = (TextView) findViewById(R.id.skydesc);
        pager = (ViewPager) findViewById(R.id.pager);
        imgView = (ImageView) findViewById(R.id.condIcon);

        JSONWeatherTask task = new JSONWeatherTask();
        task.execute(new String[]{city, lang});
        JSONWeatherTask task1 = new JSONWeatherTask();
        task1.execute(new String[]{city, lang, forecastDaysNum});



        cityText.setText(weather.location.getCity() + "," + weather.location.getCountry());
        temp.setText("" + Math.round((weather.temprature.getTemp() - 275.15)));
        condDescr.setText(weather.currentCondition.getCondition() + "(" + weather.currentCondition.getDescription() + ")");
    }
}



        class JSONWeatherTask extends AsyncTask<String, Void, WeatherForecast> {

            @Override
            protected WeatherForecast doInBackground(String... params) {

                String data = ((new WeatherHttpClient()).getForecastWeatherData(params[0], params[1], params[2]));
                WeatherForecast forecast = new WeatherForecast();
                try {
                    forecast = JSONWeatherParser.getForecastWeather(data);
                    System.out.println("Weather [" + forecast + "]");


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return forecast;

            }
        }














